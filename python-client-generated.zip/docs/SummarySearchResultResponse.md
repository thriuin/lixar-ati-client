# SummarySearchResultResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**num_found** | **int** | Number of reports found | [optional] 
**start** | **int** |  | [optional] 
**max_score** | **int** |  | [optional] 
**docs** | [**list[SummaryDocument]**](SummaryDocument.md) | A list of existing ATIP reports | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


