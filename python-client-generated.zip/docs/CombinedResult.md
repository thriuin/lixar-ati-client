# CombinedResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result_departments_json** | [**DepartmentRecommendationResult**](DepartmentRecommendationResult.md) |  | [optional] 
**result_summary_json** | [**SummarySearchResult**](SummarySearchResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


