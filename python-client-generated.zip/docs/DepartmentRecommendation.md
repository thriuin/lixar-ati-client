# DepartmentRecommendation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**department** | **str** | The recommended department | [optional] 
**relevance** | **float** | 0 &#x3D; not relevant, 100 &#x3D; totally relevant  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


