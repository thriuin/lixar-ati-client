# SummarySearchResultResponseHeaderParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**indent** | **bool** |  | [optional] 
**start** | **int** | Determines the first row to display (used for paging) | [optional] 
**q** | **str** | Text that was searched | [optional] 
**fq** | **str** |  | [optional] 
**wt** | **str** |  | [optional] 
**rows** | **int** | Number of items per &#39;page&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


