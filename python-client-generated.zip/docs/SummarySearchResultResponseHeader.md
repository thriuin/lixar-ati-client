# SummarySearchResultResponseHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 
**q_time** | **str** |  | [optional] 
**params** | [**SummarySearchResultResponseHeaderParams**](SummarySearchResultResponseHeaderParams.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


